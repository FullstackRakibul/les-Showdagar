<template>
  <div class="max-w-4xl mx-auto space-y-6 p-4 sm:p-6">
    <div>
      <h1 class="text-3xl font-bold text-gray-900 dark:text-white">About SenderBD</h1>
      <p class="mt-2 text-gray-600 dark:text-gray-400">
        SenderBD is a premium e‑commerce experience focused on quality, value, and
        reliable delivery across Bangladesh.
      </p>
    </div>

    <div
      class="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-sm border border-gray-200 dark:border-gray-700 space-y-4"
    >
      <h2 class="text-xl font-semibold text-gray-900 dark:text-white">What we offer</h2>
      <ul class="list-disc pl-5 space-y-2 text-gray-700 dark:text-gray-300">
        <li>Carefully curated products across electronics, fashion, home and more.</li>
        <li>Cash on Delivery across Bangladesh with clear delivery timelines.</li>
        <li>Fast support and transparent order tracking.</li>
      </ul>
    </div>

    <div class="bg-gradient-to-r from-emerald-500 to-teal-600 rounded-2xl p-6 text-white">
      <h3 class="text-lg font-semibold mb-2">Current Promotion</h3>
      <p class="opacity-90 mb-3">
        Google Pixel 6A (5G) 8/128GB — Japan used, but super fresh condition!
      </p>
      <div class="flex items-center space-x-4">
        <span class="text-2xl font-extrabold">৳ 20,890</span>
        <a
          href="https://wa.me/971564785090?text=I%27m%20interested%20in%20Google%20Pixel%206A%20(5G)%208/128GB%20at%2020890%20Tk"
          target="_blank"
          rel="noopener"
          class="bg-white text-emerald-600 font-semibold px-4 py-2 rounded-xl hover:bg-gray-100 transition-colors"
        >
          WhatsApp +971 564785090
        </a>
        <span class="text-xs bg-white/10 px-2 py-1 rounded-full"
          >Delivery time: 7 days</span
        >
      </div>
    </div>
  </div>
</template>
