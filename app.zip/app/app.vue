<template>
  <div class="flex h-screen overflow-hidden bg-linkedin-gray-light">
    <!-- Left Sidebar (Fixed) -->
    <div class="hidden lg:block fixed top-0 left-0 w-64 h-full z-40">
      <LeftSidebar />
    </div>

    <!-- Right Sidebar (Fixed) -->
    <div class="hidden xl:block fixed top-0 right-0 w-80 h-full z-40">
      <RightSidebar />
    </div>

    <!-- Main Content (Scrollable) -->
    <div class="flex flex-col flex-1 h-full overflow-y-auto px-4 py-4 lg:ml-64 xl:mr-80 bg-[#F4F2EE]">
      <!-- Header (Stays at top of scrollable area) -->
      <AppHeader />
      <!-- Page Content -->
      <NuxtPage />
    </div>
  </div>
</template>

<script setup>
import AppHeader from '@/components/AppHeader.vue'
import LeftSidebar from '@/components/LeftSidebar.vue'
import RightSidebar from '@/components/RightSidebar.vue'
</script>

<style>
body {
  margin: 0;
  height: 100vh;
  overflow: hidden;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
}
</style>