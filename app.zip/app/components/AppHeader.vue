<template>
  <header class="sticky top-0 z-50 bg-white border-b border-gray-200 shadow-sm">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div class="flex items-center justify-between h-16">
        <!-- Left Section: Logo & Mobile Menu -->
        <div class="flex items-center space-x-4">
          <!-- Mobile Menu Button -->
          <button class="lg:hidden text-gray-500 hover:text-gray-700 focus:outline-none"
            @click="isMobileMenuOpen = !isMobileMenuOpen">
            <i class="fas fa-bars text-2xl"></i>
          </button>

          <!-- Logo -->
          <NuxtLink to="/" class="lg:text-xl sm:text-md font-bold text-linkedin-blue">
            Les Showdagar
          </NuxtLink>
        </div>

        <!-- Middle Section: Search Bar -->
        <div class="flex-1 mx-6 max-w-lg hidden sm:block">
          <div class="relative">
            <SfInput v-model="searchQuery" placeholder="Search products..." class="w-full pl-10 pr-4" />
            <i class="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"></i>

          </div>
        </div>

        <!-- Right Section: Icons -->
        <div class="flex items-center space-x-4">
          <SfButton variant="tertiary" class="p-2">
            <i class="fas fa-home text-xl"></i>
          </SfButton>

          <SfButton variant="tertiary" class="p-2 relative" @click="showCartModal = true">
            <i class="fas fa-shopping-cart text-xl"></i>
            <span v-if="cartItemsCount > 0"
              class="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
              {{ cartItemsCount }}
            </span>
          </SfButton>

          <SfButton variant="tertiary" class="p-2">
            <i class="fas fa-user text-xl"></i>
          </SfButton>
        </div>
      </div>
    </div>

    <!-- Mobile Menu Drawer -->
    <transition name="fade">
      <div v-if="isMobileMenuOpen"
        class="lg:hidden absolute top-16 left-0 w-full bg-white border-t border-gray-200 shadow-md z-40">
        <div class="p-4 space-y-4">
          <SfInput v-model="searchQuery" placeholder="Search products..." class="w-full" />

          <div class="flex justify-around text-gray-700 text-sm">
            <button class="flex flex-col items-center gap-1 hover:text-linkedin-blue">
              <i class="fas fa-home text-xl"></i>
              Home
            </button>
            <button class="flex flex-col items-center gap-1 hover:text-linkedin-blue">
              <i class="fas fa-heart text-xl"></i>
              Wishlist
            </button>
            <button class="flex flex-col items-center gap-1 hover:text-linkedin-blue">
              <i class="fas fa-user text-xl"></i>
              Account
            </button>
          </div>
        </div>
      </div>
    </transition>

    <!-- Cart Modal -->
    <SfModal v-model="showCartModal" class="max-w-md">
      <div class="p-6">
        <h3 class="text-lg font-semibold mb-4">Shopping Cart</h3>
        <div v-if="cart.length === 0" class="text-center py-8">
          <i class="fas fa-shopping-cart text-4xl text-gray-300 mb-4"></i>
          <p class="text-gray-500">Your cart is empty</p>
        </div>
        <div v-else>
          <div v-for="item in cart" :key="item.product.id" class="flex items-center justify-between py-2 border-b">
            <div class="flex items-center">
              <img :src="item.product.image" :alt="item.product.name" class="w-12 h-12 object-cover rounded mr-3" />
              <div>
                <p class="font-medium">{{ item.product.name }}</p>
                <p class="text-sm text-gray-500">${{ item.product.price }}</p>
              </div>
            </div>
            <span class="font-semibold">{{ item.quantity }}</span>
          </div>
          <div class="mt-4 pt-4 border-t">
            <div class="flex justify-between items-center">
              <span class="font-semibold">Total Items:</span>
              <span class="font-bold">{{ cartItemsCount }}</span>
            </div>
          </div>
        </div>
      </div>
    </SfModal>
  </header>
</template>

<script setup>
import { ref } from 'vue'
import { useProducts } from '@/composables/useProducts'

const { searchQuery, cart, cartItemsCount } = useProducts()
const showCartModal = ref(false)
const isMobileMenuOpen = ref(false)
</script>

<style scoped>
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.25s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}
</style>