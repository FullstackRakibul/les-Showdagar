<template>
  <div
    class="bg-white rounded-lg border border-gray-200 hover:shadow-lg transition-shadow duration-200 overflow-hidden">
    <!-- Product Image -->
    <div class="relative cursor-pointer" @click="showProductModal = true">
      <img :src="product.image" :alt="product.name" class="w-full h-48 object-cover" />
      <div v-if="product.isNew" class="absolute top-2 left-2 bg-green-500 text-white text-xs px-2 py-1 rounded">
        NEW
      </div>
      <div v-if="product.isHot" class="absolute top-2 right-2 bg-red-500 text-white text-xs px-2 py-1 rounded">
        HOT
      </div>
      <div v-if="!product.inStock" class="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
        <span class="text-white font-semibold">Out of Stock</span>
      </div>
    </div>

    <!-- Product Info -->
    <div class="p-4">
      <h3 class="font-semibold text-gray-900 mb-1 cursor-pointer hover:text-linkedin-blue"
        @click="showProductModal = true">
        {{ product.name }}
      </h3>

      <!-- Rating -->
      <div class="flex items-center mb-2">
        <div class="flex text-yellow-400">
          <i v-for="star in 5" :key="star" :class="star <= product.rating ? 'fas fa-star' : 'far fa-star'"></i>
        </div>
        <span class="text-sm text-gray-500 ml-2">({{ product.reviews }})</span>
      </div>

      <!-- Price -->
      <div class="flex items-center mb-3">
        <span class="text-xl font-bold text-gray-900">${{ product.price }}</span>
        <span v-if="product.originalPrice" class="text-sm text-gray-500 line-through ml-2">
          ${{ product.originalPrice }}
        </span>
      </div>

      <!-- Action Buttons -->
      <div class="flex space-x-2">
        <button variant="primary" size="sm" class="flex-1 bg-linkedin-blue hover:bg-linkedin-blue-dark"
          :disabled="!product.inStock" @click="handleAddToCart">
          <i class="fas fa-cart-plus mr-1"></i>
          Add to Cart
        </button>
        <button variant="secondary" size="sm"
          class="flex-1 border-linkedin-blue text-linkedin-blue hover:bg-linkedin-blue hover:text-white"
          @click="showProductModal = true">
          View Details
        </button>
      </div>
    </div>

    <!-- Product Modal -->
    <div v-if="showProductModal" class="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center">
      <div class="max-w-2xl bg-white rounded-lg p-6">
        <div class="flex flex-col md:flex-row gap-6">
          <div class="md:w-1/2">
            <img :src="product.image" :alt="product.name" class="w-full rounded-lg">
          </div>
          <div class="md:w-1/2">
            <h2 class="text-2xl font-bold text-gray-900 mb-2">{{ product.name }}</h2>

            <!-- Rating -->
            <div class="flex items-center mb-4">
              <div class="flex text-yellow-400">
                <i v-for="star in 5" :key="star" :class="star <= product.rating ? 'fas fa-star' : 'far fa-star'"></i>
              </div>
              <span class="text-sm text-gray-500 ml-2">({{ product.reviews }} reviews)</span>
            </div>

            <!-- Price -->
            <div class="flex items-center mb-4">
              <span class="text-3xl font-bold text-gray-900">${{ product.price }}</span>
              <span v-if="product.originalPrice" class="text-lg text-gray-500 line-through ml-3">
                ${{ product.originalPrice }}
              </span>
            </div>

            <!-- Description -->
            <p class="text-gray-600 mb-6">{{ product.description }}</p>

            <!-- Stock Status -->
            <div class="mb-6">
              <span v-if="product.inStock" class="text-green-600 font-semibold">
                <i class="fas fa-check-circle mr-1"></i>
                In Stock
              </span>
              <span v-else class="text-red-600 font-semibold">
                <i class="fas fa-times-circle mr-1"></i>
                Out of Stock
              </span>
            </div>

            <!-- Action Buttons -->
            <div class="flex space-x-3">
              <button variant="primary" class="flex-1 bg-linkedin-blue hover:bg-linkedin-blue-dark"
                :disabled="!product.inStock" @click="handleAddToCart">
                <i class="fas fa-cart-plus mr-2"></i>
                Add to Cart
              </button>
              <button variant="secondary" class="border-linkedin-blue text-linkedin-blue">
                <i class="fas fa-heart"></i>
              </button>
            </div>
          </div>
        </div>
        <button class="absolute top-4 right-4 text-gray-500 hover:text-gray-700" @click="showProductModal = false">
          <i class="fas fa-times"></i>
        </button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useProducts } from '@/composables/useProducts'

const props = defineProps({
  product: {
    type: Object,
    required: true,
    product: useProducts,
  }
})

const { addToCart } = useProducts()
const showProductModal = ref(false)

const handleAddToCart = () => {
  addToCart(props.product)
  // You could add a toast notification here
}
</script>