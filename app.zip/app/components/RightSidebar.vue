<template>
  <aside class="w-80 bg-white border-l border-gray-200 h-full overflow-y-auto">
    <div class="p-4">
      <!-- Recommended Products -->
      <div class="mb-8">
        <div class="flex justify-between items-center mb-4">
          <h3 class="text-lg font-semibold text-gray-900">Recommended</h3>
          <SfButton variant="tertiary" size="sm" class="text-linkedin-blue">
            See all
          </SfButton>
        </div>
        <div class="space-y-4">
          <div v-for="product in popularProducts.slice(0, 3)" :key="product.id"
            class="flex items-center space-x-3 p-3 rounded-lg hover:bg-linkedin-gray cursor-pointer transition-colors">
            <img :src="product.image" :alt="product.name" class="w-16 h-16 object-cover rounded">
            <div class="flex-1">
              <h4 class="font-medium text-sm text-gray-900">{{ product.name }}</h4>
              <div class="flex items-center mt-1">
                <div class="flex text-yellow-400 text-xs">
                  <i v-for="star in 5" :key="star" :class="star <= product.rating ? 'fas fa-star' : 'far fa-star'"></i>
                </div>
                <span class="text-xs text-gray-500 ml-1">({{ product.reviews }})</span>
              </div>
              <p class="font-semibold text-linkedin-blue mt-1">${{ product.price }}</p>
            </div>
          </div>
        </div>
      </div>

      <!-- Hot Deals -->
      <div class="mb-8">
        <div class="flex justify-between items-center mb-4">
          <h3 class="text-lg font-semibold text-gray-900">Hot Deals</h3>
          <SfButton variant="tertiary" size="sm" class="text-linkedin-blue">
            See all
          </SfButton>
        </div>
        <div class="space-y-4">
          <div v-for="product in hotDeals" :key="product.id"
            class="bg-gradient-to-r from-red-50 to-orange-50 p-3 rounded-lg border border-red-200">
            <div class="flex items-center space-x-3">
              <img :src="product.image" :alt="product.name" class="w-12 h-12 object-cover rounded">
              <div class="flex-1">
                <h4 class="font-medium text-sm text-gray-900">{{ product.name }}</h4>
                <div class="flex items-center mt-1">
                  <span class="font-bold text-red-600">${{ product.price }}</span>
                  <span class="text-xs text-gray-500 line-through ml-2">${{ product.originalPrice }}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Recently Viewed -->
      <div>
        <h3 class="text-lg font-semibold text-gray-900 mb-4">Recently Viewed</h3>
        <div class="space-y-3">
          <div v-for="product in products.slice(0, 2)" :key="product.id"
            class="flex items-center space-x-3 p-2 rounded-lg hover:bg-linkedin-gray cursor-pointer transition-colors">
            <img :src="product.image" :alt="product.name" class="w-12 h-12 object-cover rounded">
            <div class="flex-1">
              <h4 class="font-medium text-sm text-gray-900">{{ product.name }}</h4>
              <p class="text-sm text-linkedin-blue">${{ product.price }}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </aside>
</template>

<script setup>
import { useProducts } from '@/composables/useProducts';

const { products, popularProducts, hotDeals } = useProducts();
</script>