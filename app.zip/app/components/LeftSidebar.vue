<template>
  <aside class="fixed top-0 left-0 h-screen w-64 bg-white border-r border-gray-200 flex-shrink-0 z-50">
    <div class="p-4 overflow-y-auto h-full">
      <!-- Categories -->
      <div class="mb-8">
        <h3 class="text-lg font-semibold text-gray-900 mb-3">Categories</h3>
        <ul class="space-y-2">
          <li v-for="category in categories" :key="category.name"
            class="cursor-pointer px-3 py-2 rounded-lg transition-colors flex justify-between items-center" :class="{
              'bg-blue-600 text-white': selectedCategory === category.name,
              'hover:bg-gray-100 text-gray-800': selectedCategory !== category.name
            }" @click="selectedCategory = category.name">
            <span>{{ category.name }}</span>
            <span class="text-sm opacity-70">({{ category.count }})</span>
          </li>
        </ul>
      </div>

      <!-- Quick Links -->
      <div class="mb-8">
        <h3 class="text-lg font-semibold text-gray-900 mb-3">Quick Links</h3>
        <ul class="space-y-2">
          <li class="cursor-pointer px-3 py-2 rounded-lg hover:bg-gray-100 flex items-center text-gray-700">
            <i class="fas fa-fire text-red-500 mr-2"></i>
            Hot Deals
          </li>
          <li class="cursor-pointer px-3 py-2 rounded-lg hover:bg-gray-100 flex items-center text-gray-700">
            <i class="fas fa-heart text-pink-500 mr-2"></i>
            Wishlist
          </li>
          <li class="cursor-pointer px-3 py-2 rounded-lg hover:bg-gray-100 flex items-center text-gray-700">
            <i class="fas fa-history text-blue-500 mr-2"></i>
            Recently Viewed
          </li>
        </ul>
      </div>

      <!-- Promo Box -->
      <div class="bg-gradient-to-r from-blue-600 to-blue-400 rounded-lg p-4 text-white shadow">
        <h4 class="font-semibold mb-2">Special Offer!</h4>
        <p class="text-sm mb-3">Get 20% off on your first order</p>
        <button class="w-full bg-white text-blue-600 font-medium py-2 px-4 rounded hover:bg-gray-100 transition">
          Shop Now
        </button>
      </div>
    </div>
  </aside>
</template>

<script setup>
import { useProducts } from '@/composables/useProducts'

const { categories, selectedCategory } = useProducts()
</script>